package Departamento;

import javax.swing.*;
import java.util.ArrayList;

public class Menu {

    private static ArrayList<Rodovia> rodovias = new ArrayList<Rodovia>();
    private static ArrayList<Acidente> acidentes = new ArrayList<Acidente>();

    public static void main(String[] args) {

        String menu =  "1 - Cadastrar Rodovia\n"
                + "2 - Cadastrar Acidentes\n"
                + "3 - Condutor Embrigado?\n"
                + "4 -  Qual Rodovia possui mais acidentes fatais?\n"
                + "5 - Quantidade de Acidentes por Rodovia\n"
                + "6 - Sair";

        int opcao = 0;

        do {
            opcao = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (opcao) {
                case 1:
                    Rodovia rodovia = new Rodovia();
                    rodovia.cadastra();
                    rodovias.add(rodovia);
                    break;

                case 2:
                    Acidente acidente = new Acidente();

                    for (Rodovia r: rodovias){
                        if (r.getNome().equalsIgnoreCase(JOptionPane.showInputDialog(null,"Nome da rodovia"))){

                            acidente.cadastra(r);
                        }
                    }
                    acidentes.add(acidente);
                    break;

                case 3:

                    break;

                default:
                    opcao = 6;
            }

            System.out.println(acidentes);
        } while (opcao != 6);
    }
    public static void exibeAcidentesComCondutoresEmbrigados(){
        String acidentesComCondutorEmbrigado = " ";

        for (Acidente acidentes : acidentes){
            boolean algumCondutorBebum = false;

            if (acidentes.getAlgumcondutorBebo  ()){
                acidentesComCondutorEmbrigado += acidentes;
            }

        }
        JOptionPane.showInputDialog(null, " ");
    }

}