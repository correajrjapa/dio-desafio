package Departamento;

import javax.swing.JOptionPane;
import java.util.ArrayList;

public class Acidente {
    private Rodovia rodovia = new Rodovia();
    private int vitimasFatais = -1;
    private ArrayList<Veiculo> veiculosEnvolvidos = new ArrayList<Veiculo>();

    public void cadastra(Rodovia rodovia) {
        setRodovia(rodovia);
        setVitimasFatais(Integer.parseInt(JOptionPane.showInputDialog(null, "Quantidade de Vitimas Fatais")));

        int qtdeVeiculos = Integer.
                parseInt(JOptionPane.showInputDialog(null, "Digite a quantidade de Veiculos que se bateram"));

        for (int i = 1; i <= qtdeVeiculos; i++) {
            Veiculo veiculo = new Veiculo();
            veiculo.cadastra();
            veiculosEnvolvidos.add(veiculo);
        }
    }

    public boolean getAlgumcondutorBebo() {

        for (Veiculo v : veiculosEnvolvidos) {
             if (v.getAlgumcondutorBebo()) {
                return true;

             }
        }
        return false;
    }

    public Rodovia getRodovia() {
       return rodovia;
    }

    public void setRodovia(Rodovia rodovia) {
        this.rodovia = rodovia;
    }

    public Integer getVitimasFatais() {
        return vitimasFatais;
    }

    public void setVitimasFatais(Integer vitimasFatais) {
        this.vitimasFatais = vitimasFatais;
    }

    public ArrayList<Veiculo> getVeiculosEnvolvidos() {
        return veiculosEnvolvidos;
    }

    public void setVeiculosEnvolvidos(ArrayList<Veiculo> veiculosEnvolvidos) {
        this.veiculosEnvolvidos = veiculosEnvolvidos;
    }

    @Override
    public String toString() {
        return "Acidentes{" +
                "rodovia=" + rodovia +
                ", vitimasFatais=" + vitimasFatais +
                ", veiculosEnvolvidos=" + veiculosEnvolvidos +
                '}';
    }
}
