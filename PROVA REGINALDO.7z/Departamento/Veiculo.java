package Departamento;

import javax.swing.JOptionPane;

public class Veiculo {
    private int anofabric = -1;
    private Condutor condutor = new Condutor();

    public void cadastra(){
        setAnofabric(Integer.
                parseInt(JOptionPane.showInputDialog(null, "Ano de Fabricação do Car")));
        condutor.cadastra();
        setCondutor(condutor);
    }

    public boolean getAlgumcondutorBebo(){
        return condutor.isEmbriagado() == '1';

    }

    public int getAnofabric() {
        return anofabric;
    }

    public void setAnofabric(int anofabric) {
        this.anofabric = anofabric;
    }

    public Condutor getCondutor() {
        return condutor;
    }

    public void setCondutor(Condutor condutor) {
        this.condutor = condutor;
    }

    @Override
    public String toString() {
        return "Veiculo{" +
                "anofabric=" + anofabric +
                ", condutor=" + condutor +
                '}';
    }
}
