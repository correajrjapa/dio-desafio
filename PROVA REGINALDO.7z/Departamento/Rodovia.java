package Departamento;

import javax.swing.JOptionPane;

public class Rodovia {

    private String nome;
    private Double kmTotal = 0.0;

        public void cadastra() {
        setNome (JOptionPane.showInputDialog(null, " Digite o nome da Rodovia"));
        setKmTotal (Double.parseDouble(JOptionPane.showInputDialog(null, " Digite a Distância total da Rodovia (KM)")));
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Double getKmTotal() {
        return kmTotal;
    }

    public void setKmTotal(Double kmTotal) {
        this.kmTotal = kmTotal;
    }

    @Override
    public String toString() {
        return "Rodovia{" +
                "nome='" + nome + '\'' +
                ", kmTotal=" + kmTotal +
                '}';
    }
}
