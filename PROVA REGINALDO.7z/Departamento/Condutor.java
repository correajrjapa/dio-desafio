package Departamento;

import javax.swing.JOptionPane;

public class Condutor {
    private String nome = " ";
    private Integer idade = -1;
    private char sexo= ' ';
    private char embriagado = ' ';

    public void cadastra(){
        setNome ((JOptionPane.showInputDialog(null, "Digite o nome do condutor" +
                "")));
        setIdade(Integer.parseInt(JOptionPane.showInputDialog(null, "Digite a idade do condutor")));
        setSexo(JOptionPane.showInputDialog(null, "Digite o sexo do Condutor(M/F"). charAt(0));
        setEmbriagado(JOptionPane.showInputDialog(null, "O  Condutor estava bebaum? (1/0)").charAt(0));
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getIdade() {
        return idade;
    }

    public void setIdade(Integer idade) {
        this.idade = idade;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public char isEmbriagado() {
        return embriagado;
    }

    public void setEmbriagado(char embrigado) {
        this.embriagado = embrigado;
    }

    @Override
    public String toString() {
        return "Condutores{" +
                "nome='" + nome + '\'' +
                ", idade=" + idade +
                ", sexo=" + sexo +
                ", embrigado=" + embriagado +
                '}';
    }
}
